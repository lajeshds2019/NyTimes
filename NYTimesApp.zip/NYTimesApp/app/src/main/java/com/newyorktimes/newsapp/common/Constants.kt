package com.newyorktimes.newsapp.common

/****
 * Keep all the common constants here
 * Author: Lajesh Dineshkumar
 * Created on: 18/12/19
 * Modified on: 18/12/19
 *****/
object Constants {
    const val QUERY_PARAM__APIKEY = "api-key"
}