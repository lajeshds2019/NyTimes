package com.newyorktimes.newsapp.architecture

import android.databinding.BindingAdapter
import android.widget.ImageView
import com.bumptech.glide.Glide

/****
 * Keep all static binding adapters here
 * Author: Lajesh Dineshkumar
 * Created on: 18/12/19
 * Modified on: 18/12/19
 *****/
object BindingAdapters {
    @JvmStatic
    @BindingAdapter("bind:imageUrl")
    fun loadImage(view: ImageView, url: String) {
        Glide.with(view.context).load(url)
            .override(150, 150)
            .centerCrop()
            .into(view)
    }

    
}