package com.newyorktimes.newsapp.common

/****
 * Keep all the Json key constants here
 * Author: Lajesh Dineshkumar
 * Created on: 18/12/19
 * Modified on: 18/12/19
 *****/
object JsonKeyConstants{
    // Keep Json Keyconstants here

}